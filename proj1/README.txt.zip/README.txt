Peter Palumbo
Assignment 1
1-18-1

Using Ubuntu
Password changed succesfully after a few tries of forgetting a ';' and forgetting to enclose password in "'"s
My generated haiku read "Wisdom bends midday, A fair spice stings yet fear plays, Greenly tal hairs walk."
After playing around a bit I found many terminal commands do not work in the SQL like I thought they would.
This assignment was a good start and I'm excited to learn more.
